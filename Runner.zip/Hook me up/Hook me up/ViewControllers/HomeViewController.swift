//
//  HomeViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 5/2/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class HomeViewController: UIViewController {
    
    var dollar: UILabel!
    var logo: UIImageView!
    var signIn: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        self.navigationController?.navigationBar.isHidden = true
                
        dollar = UILabel()
        dollar.text = "$"
        dollar.font = UIFont(name: "Montserrat-SemiBold", size: 35)
        dollar.textColor = .white
        view.addSubview(dollar)
        
        logo = UIImageView()
        logo.image = UIImage(named: "Logo")
        logo.contentMode = .scaleAspectFill
        view.addSubview(logo)
        
        signIn = UIButton()
        signIn.setTitle("Sign In", for: .normal)
        signIn.setTitleColor(UIColorFromHex(rgbValue: 0x65C742, alpha: 1), for: .normal)
        signIn.layer.cornerRadius = 10
        signIn.backgroundColor = .white
        signIn.titleLabel?.textAlignment = .center
        signIn.titleLabel?.font = UIFont(name: "Montserrat-SemiBold", size: 14)
        signIn.addTarget(self, action: #selector(signInAction), for: .touchUpInside)
        view.addSubview(signIn)

        setUpConstraints()

        // Do any additional setup after loading the view.
    }
    
    func setUpConstraints() {
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(6)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        logo.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.centerY).offset(-50)
            make.height.equalTo(72)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(30)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
        }
        
        signIn.snp.makeConstraints { (make) in
            make.top.equalTo(logo.snp.bottom).offset(150)
            make.height.equalTo(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
    }
    
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    @objc func signInAction() {

        let vc = JobViewController()
        let transition = CATransition()
        transition.duration = 0.4
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromRight
        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        view.window!.layer.add(transition, forKey: kCATransition)
        present(vc, animated: false, completion: nil)
    }
    

}
