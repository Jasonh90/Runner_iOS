//
//  PlusViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/22/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit
import iOSDropDown

class PlusViewController: UIViewController {
    
    var dollar: UIButton!
    var plusButton: UIButton!
    var createJob: UILabel!
    var tableView: UITableView!
    var fieldNames: [CreateJobFieldsClass]!
    var jobHistory: UILabel!
    
    let reuseIdentifier1 = "reuseIdentifier1"
    let reuseIdentifier2 = "reuseIdentifier2"
    let reuseIdentifier3 = "reuseIdentifier3"
    let cellHeight1: CGFloat = 35
    let cellHeight2: CGFloat = 100
    
    var textFieldCells: [JobCreationTableViewCell]!
    
//    var category: DropDown!
//    let picker = UIDatePicker()

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1.0)
        
        textFieldCells = []
        
        let field1 = CreateJobFieldsClass(fieldName: "Job Title")
        let field2 = CreateJobFieldsClass(fieldName: "Cost of Job")
        let field3 = CreateJobFieldsClass(fieldName: "Profit of Runner")
        let field4 = CreateJobFieldsClass(fieldName: "Total Payment")
        let field5 = CreateJobFieldsClass(fieldName: "Category")
        let field6 = CreateJobFieldsClass(fieldName: "First Address")
        let field7 = CreateJobFieldsClass(fieldName: "Last Address")
        let field8 = CreateJobFieldsClass(fieldName: "Start Time")
        let field9 = CreateJobFieldsClass(fieldName: "End Time")
        let field10 = CreateJobFieldsClass(fieldName: "Date")
        let field11 = CreateJobFieldsClass(fieldName: "Job Dsecription")
        
        fieldNames = [field1, field2, field3, field4, field5, field6, field7, field8, field9, field10, field11]

        plusButton = UIButton()
        plusButton.setImage(UIImage(named:"Plus Sign"), for: .normal)
        view.addSubview(plusButton)
        
        dollar = UIButton()
        dollar.setTitle("$", for: .normal)
        dollar.titleLabel?.font = UIFont(name: "Montserrat", size: 100)
        dollar.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        dollar.addTarget(self, action: #selector(dollarButtonTapped), for: .touchUpInside)
        view.addSubview(dollar)
        
        createJob = UILabel()
        createJob.text = "Create Your Job"
        createJob.textColor = .white
        createJob.layer.masksToBounds = true
        createJob.layer.cornerRadius = 4
        createJob.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        createJob.textAlignment = .center
        createJob.font = UIFont(name: "Montserrat-Bold", size: 24)
        view.addSubview(createJob)
        
        tableView = UITableView()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(JobCreationTableViewCell.self, forCellReuseIdentifier: reuseIdentifier1)
        tableView.register(JobDescriptionTableViewCell.self, forCellReuseIdentifier: reuseIdentifier2)
        tableView.register(DropDownTableViewCell.self, forCellReuseIdentifier: reuseIdentifier3)

        view.addSubview(tableView)
        
        jobHistory = UILabel()
        jobHistory.text = "Job History"
        jobHistory.textColor = .white
        jobHistory.layer.masksToBounds = true
        jobHistory.layer.cornerRadius = 4
        jobHistory.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        jobHistory.textAlignment = .center
        jobHistory.font = UIFont(name: "Montserrat-Bold", size: 24)
        view.addSubview(jobHistory)
        
        setUpConstraints()
    }

    
    func setUpConstraints() {

        
        plusButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(15)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(80)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        createJob.snp.makeConstraints { (make) in
            make.top.equalTo(plusButton.snp.bottom).offset(10)
            make.bottom.equalTo(plusButton.snp.bottom).offset(62)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        tableView.snp.makeConstraints { (make) in
            make.top.equalTo(createJob.snp.bottom)
//            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-70)
            make.bottom.equalTo(tableView.snp.top).offset(450)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        jobHistory.snp.makeConstraints { (make) in
            make.top.equalTo(tableView.snp.bottom)
            make.bottom.equalTo(jobHistory.snp.top).offset(52)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
    }
    
    func jobPostingDictionary(fieldCells: [JobCreationTableViewCell]) {

        var posting = [String: Any]()
        posting["title"] = fieldCells[1].textField.text
        
        if let cst = Int(fieldCells[2].textField.text ?? "") {
            posting["cost"] = cst
        }
        else {
            posting["cost"] = 0

        }
        
        if let profit = Int(fieldCells[3].textField.text ?? "") {
            posting["profit"] = profit
        }
        else {
            posting["profit"] = 0
            
        }
        
        if let tot = Int(fieldCells[4].textField.text ?? "") {
            posting["amountpaidtoworker"] = tot
        }
        else {
            posting["amountpaidtoworker"] = 0
            
        }
        posting["category"] = fieldCells[5].textField.text
        posting["first_Add"] = fieldCells[6].textField.text
        posting["last_Add"] = fieldCells[7].textField.text
        posting["start_time"] = fieldCells[8].textField.text
        posting["end_time"] = fieldCells[9].textField.text
        posting["date"] = fieldCells[10].textField.text
        posting["description"] = fieldCells[11].textField.text
        
        JobNetworkManager.postJob(posting: posting)
    }
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    @objc func dollarButtonTapped() {
        let transition = CATransition()
        transition.duration = 0.4
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        view.window!.layer.add(transition, forKey: kCATransition)
        dismiss(animated: false, completion: nil)
        
    }
    
}

extension PlusViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 11 {
            return cellHeight2
        }
        return cellHeight1
    }
    
    // TODO: Did not check to see if valid post request sent or not
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 11 {
            jobPostingDictionary(fieldCells: textFieldCells)
//            JobViewController.getJobEntries()
            present(PostingCompletedViewController(), animated: true, completion: nil)
        }
    }
    
}

extension PlusViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return fieldNames.count + 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == 11 {
            let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier2, for: indexPath) as! JobDescriptionTableViewCell
            cell.selectionStyle = .none
            return cell
            
        }

        else {
            let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier1, for: indexPath) as! JobCreationTableViewCell
            let field = fieldNames[indexPath.row]
            cell.configure(for: field)
            textFieldCells.append(cell)
            cell.selectionStyle = .none
            return cell
        }

    }
}

