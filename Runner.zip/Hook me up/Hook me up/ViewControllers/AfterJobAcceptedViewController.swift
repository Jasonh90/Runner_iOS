//
//  ViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/21/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class AfterJobPostingViewController: UIViewController {
    
    var profileButton: UIButton!
    var plusButton: UIButton!
    var dollar: UILabel!
    var moneyEarned: UILabel!
    var moneyAmount: UILabel!
    var smallDollar: UILabel!
    var jobPostings: UILabel!
    var mostRecent: UIButton!
    var allCategories: UIButton!
    var currentJob: UILabel!
    
    var jobPostingsTable: UITableView!
    let reuseIdentifier = "Job Postings"
    
    var currentJobPostingsTable: UIView!
    let currentJobsreuseIdentifier = "current Jobs"
    
    var postings: [jobDetailsClass]!
    let cellHeight: CGFloat = 85
    
    var refreshControl: UIRefreshControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Setting the background color
        postings = []
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        self.navigationController?.navigationBar.isHidden = true
        
        
        //Initializing the buttons
        profileButton = UIButton()
        profileButton.setImage(UIImage(named:"Profile Icon"), for: .normal)
        profileButton.addTarget(self, action: #selector(profileButtonTapped), for: .touchUpInside)
        view.addSubview(profileButton)
        
        plusButton = UIButton()
        plusButton.setImage(UIImage(named: "Plus Sign"), for: .normal)
        plusButton.addTarget(self, action: #selector(plusButtonTapped), for: .touchUpInside)
        view.addSubview(plusButton)
        
        //Initalizing the labels
        dollar = UILabel()
        dollar.text = "$"
        dollar.font = UIFont(name: "Montserrat-SemiBold", size: 35)
        dollar.textColor = .white
        view.addSubview(dollar)
        
        moneyEarned = UILabel()
        moneyEarned.text = "Money Earned:"
        moneyEarned.font = UIFont(name: "Montserrat-Regular", size: 20)
        moneyEarned.textColor = .white
        view.addSubview(moneyEarned)
        
        moneyAmount = UILabel()
        moneyAmount.text = "15.00"
        moneyAmount.font = UIFont(name: "Montserrat-Bold", size: 40)
        moneyAmount.textColor = .white
        view.addSubview(moneyAmount)
        
        smallDollar = UILabel()
        smallDollar.text = "$"
        smallDollar.font = UIFont(name: "Montserrat", size: 20)
        smallDollar.textColor = .white
        view.addSubview(smallDollar)
        
        jobPostings = UILabel()
        jobPostings.text = "Job Postings"
        jobPostings.textColor = .white
        jobPostings.layer.masksToBounds = true
        jobPostings.layer.cornerRadius = 4
        jobPostings.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        jobPostings.textAlignment = .center
        jobPostings.font = UIFont(name: "Montserrat-Bold", size: 24)
        view.addSubview(jobPostings)
        
        mostRecent = UIButton()
        mostRecent.setTitle("Most Recent", for: .normal)
        mostRecent.setTitleColor(UIColorFromHex(rgbValue: 0xBDB6B6, alpha: 1.0), for: .normal)
        mostRecent.layer.masksToBounds = false
        mostRecent.layer.cornerRadius = 2
        mostRecent.backgroundColor = UIColorFromHex(rgbValue: 0xFFFFFF, alpha: 1.0)
        mostRecent.titleLabel?.textAlignment = .center
        mostRecent.layer.borderColor = UIColorFromHex(rgbValue: 0xBDB6B6, alpha: 1.0).cgColor
        mostRecent.titleLabel?.font = UIFont(name: "Montserrat-Regular", size: 16)
        view.addSubview(mostRecent)
        
        allCategories = UIButton()
        allCategories.setTitle("All Categories", for: .normal)
        allCategories.setTitleColor(UIColorFromHex(rgbValue: 0xBDB6B6, alpha: 1.0), for: .normal)
        allCategories.layer.masksToBounds = false
        allCategories.layer.cornerRadius = 2
        allCategories.backgroundColor = UIColorFromHex(rgbValue: 0xFFFFFF, alpha: 1.0)
        allCategories.titleLabel?.textAlignment = .center
        allCategories.layer.borderColor = UIColorFromHex(rgbValue: 0xBDB6B6, alpha: 1.0).cgColor
        allCategories.titleLabel?.font = UIFont(name: "Montserrat-Regular", size: 16)
        view.addSubview(allCategories)
        
        refreshControl = UIRefreshControl()
        refreshControl.addTarget(self, action: #selector(pulledToRefresh), for: .valueChanged)
        
        jobPostingsTable = UITableView()
        jobPostingsTable.register(JobsTableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        jobPostingsTable.delegate = self
        jobPostingsTable.dataSource = self
        jobPostingsTable.refreshControl = refreshControl
        view.addSubview(jobPostingsTable)
        
        
        currentJob = UILabel()
        currentJob.text = "Current Jobs"
        currentJob.textColor = .white
        currentJob.layer.masksToBounds = true
        currentJob.layer.cornerRadius = 4
        currentJob.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        currentJob.textAlignment = .center
        currentJob.font = UIFont(name: "Montserrat-Bold", size: 24)
        view.addSubview(currentJob)
        
//        currentJobPostingsTable = UITableView()
//        currentJobPostingsTable.register(CurrentJobTableViewCell.self, forCellReuseIdentifier: currentJobsreuseIdentifier)
//        currentJobPostingsTable.delegate = self
//        currentJobPostingsTable.dataSource = self
//        currentJobPostingsTable.refreshControl = refreshControl
//        view.addSubview(currentJobPostingsTable)
        
        getJobEntries()
        setUpConstraints()
        
    }
    
    func getJobEntries() {
        JobNetworkManager.getJobs { (jobs) in
            self.postings = jobs
            DispatchQueue.main.async {
                self.jobPostingsTable.reloadData()
            }
        }
    }
    
    @objc func pulledToRefresh() {
        // Place some code here that fetches new data
        // Then call refreshControl.endRefreshing() once we get that data back
        JobNetworkManager.getJobs { (jobs) in
            self.postings = jobs
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                self.refreshControl.endRefreshing()
                self.jobPostingsTable.reloadData()
            }
        }
    }
    
    func setUpConstraints() {
        
        profileButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(80)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        plusButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-70)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-10)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(6)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        moneyEarned.snp.makeConstraints { (make) in
            make.top.equalTo(dollar.snp.bottom).offset(5)
            make.centerX.equalTo(view.snp.centerX)
            make.height.equalTo(30)
            
        }
        
        moneyAmount.snp.makeConstraints { (make) in
            make.top.equalTo(moneyEarned.snp.bottom)
            make.centerX.equalTo(view.snp.centerX).offset(5)
            make.height.equalTo(40)
        }
        
        smallDollar.snp.makeConstraints { (make) in
            make.top.equalTo(moneyEarned.snp.bottom).offset(5)
            make.trailing.equalTo(moneyAmount.snp.leading)
            make.height.equalTo(40)
        }
        
        currentJob.snp.makeConstraints { (make) in
            make.top.equalTo(moneyAmount.snp.bottom).offset(8)
            make.bottom.equalTo(moneyAmount.snp.bottom).offset(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        jobPostings.snp.makeConstraints { (make) in
            make.top.equalTo(moneyAmount.snp.bottom).offset(8)
            make.bottom.equalTo(moneyAmount.snp.bottom).offset(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        mostRecent.snp.makeConstraints { (make) in
            make.top.equalTo(jobPostings.snp.bottom)
            make.bottom.equalTo(jobPostings.snp.bottom).offset(40)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.centerX)
        }
        
        allCategories.snp.makeConstraints { (make) in
            make.top.equalTo(jobPostings.snp.bottom)
            make.bottom.equalTo(jobPostings.snp.bottom).offset(40)
            make.leading.equalTo(mostRecent.snp.trailing)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        jobPostingsTable.snp.makeConstraints { (make) in
            make.top.equalTo(allCategories.snp.bottom)
            make.bottom.equalTo(view.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        
    }
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    @objc func profileButtonTapped() {
        let profileVC = ProfileViewController()
        let transition = CATransition()
        transition.duration = 0.4
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromLeft
        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        view.window!.layer.add(transition, forKey: kCATransition)
        present(profileVC, animated: false, completion: nil)
        //        navigationController?.pushViewController(profileVC, animated: true)
        
    }
    
    @objc func plusButtonTapped() {
        let profileVC = PlusViewController()
        let transition = CATransition()
        transition.duration = 0.4
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromRight
        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        view.window!.layer.add(transition, forKey: kCATransition)
        present(profileVC, animated: false, completion: nil)
    }
    
}

extension AfterJobPostingViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return cellHeight
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let jvc = JobPostingViewController()
        jvc.job = postings[indexPath.row]
        present(jvc, animated: true, completion: nil)
        //        self.navigationController?.pushViewController(jvc, animated: true)
    }
    
}

extension AfterJobPostingViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return postings.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! JobsTableViewCell
        
        let posting = postings[indexPath.row]
        cell.configure(for: posting)
        cell.selectionStyle = .none
        return cell
    }
    
    
}


