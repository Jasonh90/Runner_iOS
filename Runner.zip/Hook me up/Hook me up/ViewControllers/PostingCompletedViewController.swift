//
//  PostingCompletedViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 5/5/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class PostingCompletedViewController: UIViewController {
    
    var label1: UILabel!
    var label2: UILabel!
    var label3: UILabel!
    var dollar: UILabel!
    
    var postingsButton: UIButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        self.navigationController?.navigationBar.isHidden = true
        
        dollar = UILabel()
        dollar.text = "$"
        dollar.font = UIFont(name: "Montserrat-SemiBold", size: 35)
        dollar.textColor = .white
        view.addSubview(dollar)
        
        label1 = UILabel()
        label1.text = "YOUR JOB"
        label1.textAlignment = .center
        label1.textColor = .white
        label1.font = UIFont(name: "Montserrat-BlackItalic", size: 48)
        view.addSubview(label1)
        
        label2 = UILabel()
        label2.text = "WAS"
        label2.textAlignment = .center
        label2.textColor = .white
        label2.font = UIFont(name: "Montserrat-BlackItalic", size: 48)
        view.addSubview(label2)
        
        label3 = UILabel()
        label3.text = "CREATED!"
        label3.textAlignment = .center
        label3.textColor = .white
        label3.font = UIFont(name: "Montserrat-BlackItalic", size: 48)
        view.addSubview(label3)
        
        postingsButton = UIButton()
        postingsButton.setTitle("Go Back!", for: .normal)
        postingsButton.setTitleColor(UIColorFromHex(rgbValue: 0x65C742, alpha: 1), for: .normal)
        postingsButton.layer.cornerRadius = 10
        postingsButton.backgroundColor = .white
        postingsButton.titleLabel?.textAlignment = .center
        postingsButton.titleLabel?.font = UIFont(name: "Montserrat-SemiBold", size: 14)
        postingsButton.addTarget(self, action: #selector(postingsButtonAction), for: .touchUpInside)
        view.addSubview(postingsButton)
        

        setUpConstraints()
        // Do any additional setup after loading the view.
    }
    
    func setUpConstraints() {
        postingsButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-90)
            make.height.equalTo(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
        
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(6)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        label1.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(200)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(label1.snp.top).offset(70)
        }
        
        label2.snp.makeConstraints { (make) in
            make.top.equalTo(label1.snp.bottom).offset(10)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(label2.snp.top).offset(70)
        }
        
        label3.snp.makeConstraints { (make) in
            make.top.equalTo(label2.snp.bottom).offset(10)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(label3.snp.top).offset(70)
        }
        
    }
    
    @objc func postingsButtonAction() {
        dismiss(animated: true, completion: nil)
    }
    

    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }

}
