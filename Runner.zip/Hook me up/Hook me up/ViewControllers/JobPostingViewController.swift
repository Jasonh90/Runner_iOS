//
//  JobPostingInformationViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 5/4/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class JobPostingViewController: UIViewController {
    
    var job: jobDetailsClass?
    
    var backButton: UIButton!
    var dollar: UILabel!
    var headingLabel1: UILabel!
    var headingLabel2: UILabel!
    var headingView: UIView!
    var jobDescription: UILabel!
    var startingAddress: UILabel!
    var endingAddress: UILabel!
    var startEnd: UIImageView!
    var cost: UILabel!
    var profit: UILabel!
    var total: UILabel!
    var totalProfit: UILabel!
    var getHired: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        self.navigationController?.navigationBar.isHidden = true
        
        dollar = UILabel()
        dollar.text = "$"
        dollar.font = UIFont(name: "Montserrat-SemiBold", size: 35)
        dollar.textColor = .white
        view.addSubview(dollar)
        
        headingView = UIView()
        headingView.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        headingView.layer.cornerRadius = 10
        view.addSubview(headingView)
        
        headingLabel1 = UILabel(frame: CGRect(x: 5, y: 0, width: 300, height: 60))
        headingLabel1.text = "\(job!.title)"
        headingLabel1.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        headingLabel1.textColor = .white
        headingLabel1.font = UIFont(name: "Montserrat-Bold", size: 32)
        headingLabel1.textAlignment = .center
        headingView.addSubview(headingLabel1)
        
        headingLabel2 = UILabel(frame: CGRect(x: 5, y: 55, width: 300, height: 15))
        headingLabel2.text = "\(job!.category) @\(job!.start_time) \(job!.date)"
        headingLabel2.backgroundColor = UIColorFromHex(rgbValue: 0xADA7A7, alpha: 1)
        headingLabel2.textColor = .white
        headingLabel2.font = UIFont(name: "Montserrat-Regular", size: 16)
        headingLabel2.textAlignment = .center
        headingView.addSubview(headingLabel2)
        
        backButton = UIButton()
        backButton.setTitle("< Back", for: .normal)
        backButton.setTitleColor(.white, for: .normal)
        backButton.titleLabel?.font = UIFont(name: "Montserrat-Regular", size: 18)
        backButton.titleLabel?.textAlignment = .left
        backButton.addTarget(self, action: #selector(backButtonPressed), for: .touchUpInside)
        view.addSubview(backButton)
        
        jobDescription = UILabel()
        jobDescription.text = "\"\(job!.description)\""
        jobDescription.textColor = .white
        jobDescription.font = UIFont(name: "Montserrat-Regular", size: 16)
        jobDescription.lineBreakMode = .byWordWrapping
        jobDescription.numberOfLines = 0
        view.addSubview(jobDescription)
        
        startingAddress = UILabel()
        startingAddress.text = "\(job!.first_Add)"
        startingAddress.textColor = .white
        startingAddress.font = UIFont(name: "Montserrat-SemiBold", size: 16)
        view.addSubview(startingAddress)
        
        endingAddress = UILabel()
        endingAddress.text = "\(job!.last_Add)"
        endingAddress.textColor = .white
        endingAddress.font = UIFont(name: "Montserrat-SemiBold", size: 16)
        view.addSubview(endingAddress)
        
        cost = UILabel()
        cost.text = "Cost: $\(job!.cost)"
        cost.textColor = .white
        cost.font = UIFont(name: "Montserrat-Regular", size: 16)
        view.addSubview(cost)
        
        profit = UILabel()
        profit.text = "Profit: $\(job!.profit)"
        profit.textColor = .white
        profit.font = UIFont(name: "Montserrat-Regular", size: 16)
        view.addSubview(profit)
        
        total = UILabel()
        total.text = "Recieving: $\(job!.amountpaidtoworker)"
        total.textColor = .white
        total.font = UIFont(name: "Montserrat-Regular", size: 16)
        view.addSubview(total)
        
        totalProfit = UILabel()
        totalProfit.text = "$\(job!.profit)"
        totalProfit.textColor = .white
        totalProfit.font = UIFont(name: "Montserrat-Bold", size: 34)
        totalProfit.textAlignment = .center
        view.addSubview(totalProfit)
        
        startEnd = UIImageView()
        startEnd.image = UIImage(named: "start-end")
        startEnd.contentMode = .scaleAspectFill
        view.addSubview(startEnd)
        
        getHired = UIButton()
        getHired.setTitle("Get Hired!", for: .normal)
        getHired.setTitleColor(UIColorFromHex(rgbValue: 0x65C742, alpha: 1), for: .normal)
        getHired.layer.cornerRadius = 10
        getHired.backgroundColor = .white
        getHired.titleLabel?.textAlignment = .center
        getHired.titleLabel?.font = UIFont(name: "Montserrat-SemiBold", size: 14)
//        getHired.addTarget(self, action: #selector(signInAction), for: .touchUpInside)
        view.addSubview(getHired)
        
        
        setUpConstraints()
    }
    
    @objc func backButtonPressed() {
        dismiss(animated: true, completion: nil)
    }
    
    func setUpConstraints() {
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(6)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        backButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(120)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        headingView.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(80)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(30)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(170)
        }
        
        jobDescription.snp.makeConstraints { (make) in
            make.top.equalTo(headingView.snp.bottom).offset(5)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(40)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-40)
            make.bottom.equalTo(jobDescription.snp.top).offset(140)
        }
        
        startingAddress.snp.makeConstraints { (make) in
            make.top.equalTo(jobDescription.snp.bottom).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(60)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
            make.bottom.equalTo(startingAddress.snp.top).offset(20)
        }
        
        endingAddress.snp.makeConstraints { (make) in
            make.top.equalTo(startingAddress.snp.bottom).offset(20)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(60)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
            make.bottom.equalTo(endingAddress.snp.top).offset(20)
        }
        
        startEnd.snp.makeConstraints { (make) in
            make.top.equalTo(startingAddress.snp.top).offset(5)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(46)
            make.trailing.equalTo(startEnd.snp.leading)
            make.bottom.equalTo(endingAddress.snp.bottom).offset(-5)
        }
        
        cost.snp.makeConstraints { (make) in
            make.top.equalTo(endingAddress.snp.bottom).offset(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(50)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(190)
            make.bottom.equalTo(cost.snp.top).offset(15)
        }
        
        profit.snp.makeConstraints { (make) in
            make.top.equalTo(cost.snp.bottom).offset(5)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(50)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(190)
            make.bottom.equalTo(profit.snp.top).offset(20)
        }
        
        total.snp.makeConstraints { (make) in
            make.top.equalTo(profit.snp.bottom).offset(5)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(50)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(190)
            make.bottom.equalTo(total.snp.top).offset(20)
        }
        
        totalProfit.snp.makeConstraints { (make) in
            make.top.equalTo(cost.snp.top).offset(2)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-120)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-50)
            make.bottom.equalTo(total.snp.bottom)
        }
        
        getHired.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-90)
            make.height.equalTo(50)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(20)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-20)
        }
    }
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }


}
