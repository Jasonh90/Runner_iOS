//
//  ProfileViewController.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/21/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class ProfileViewController: UIViewController {
    
    var dollar: UIButton!
    var profileButton: UIButton!
    var profilePicture: UIImageView!
    var userName: UILabel!
    var ratingLabel: UILabel!
    var jobsCreated: UILabel!
    var jobsDone: UILabel!
    var moneyEarned: UILabel!
    var jobsCreatedAmt: UILabel!
    var moneyEarnedAmt: UILabel!
    var jobsDoneAmt: UILabel!
    var personalLabel: UILabel!
    var textField1: UITextField!
    var textField2: UITextField!
    var textField3: UITextField!
    var editButton: UIButton!
    
    let buttonHeight: CGFloat = 100
    
    let height: CGFloat = 145

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        
        dollar = UIButton()
        dollar.setTitle("$", for: .normal)
        dollar.titleLabel?.font = UIFont(name: "Montserrat-SemiBold", size: 35)
//        dollar.titleLabel?.font = UIFont.boldSystemFont(ofSize: 35)
        dollar.addTarget(self, action: #selector(dollarButtonTapped), for: .touchUpInside)
        view.addSubview(dollar)
        
        profileButton = UIButton()
        profileButton.setImage(UIImage(named:"Profile Icon"), for: .normal)
        view.addSubview(profileButton)
        
        profilePicture = UIImageView()
        profilePicture.image = UIImage(named: "Kompella")
        profilePicture.layer.masksToBounds = true
        profilePicture.layer.borderColor = UIColor.white.cgColor
        profilePicture.layer.borderWidth = 2
        profilePicture.layer.cornerRadius = height/2
        profilePicture.contentMode = .scaleAspectFill
        profilePicture.clipsToBounds = true
        view.addSubview(profilePicture)
        
        userName = UILabel()
        userName.text = "Javier Correa"
        userName.textColor = .white
        userName.textAlignment = .center
        userName.font = UIFont(name: "Montserrat-SemiBold", size: 28)
        view.addSubview(userName)
        
        ratingLabel = UILabel()
        ratingLabel.text = "4.29"
        ratingLabel.textColor = UIColorFromHex(rgbValue: 0x96Df7D, alpha: 1.0)
        ratingLabel.textAlignment = .center
        ratingLabel.font = UIFont(name: "Montserrat", size: 20)
        ratingLabel.font = UIFont.boldSystemFont(ofSize: 18)
        view.addSubview(ratingLabel)
        
        jobsCreated = UILabel()
        jobsCreated.text = "Jobs Created:"
        jobsCreated.textColor = .white
        jobsCreated.textAlignment = .center
        jobsCreated.font = UIFont(name: "Montserrat-Regular", size: 16)
        jobsCreated.lineBreakMode = .byWordWrapping
        jobsCreated.numberOfLines = 0
        view.addSubview(jobsCreated)
        
        
        jobsDone = UILabel()
        jobsDone.text = "Jobs Done:"
        jobsDone.textColor = .white
        jobsDone.textAlignment = .center
        jobsDone.font = UIFont(name: "Montserrat-Regular", size: 16)
        jobsDone.lineBreakMode = .byWordWrapping
        jobsDone.numberOfLines = 0
        view.addSubview(jobsDone)
        
        moneyEarned = UILabel()
        moneyEarned.text = "Money Earned:"
        moneyEarned.textColor = .white
        moneyEarned.textAlignment = .center
        moneyEarned.font = UIFont(name: "Montserrat-Regular", size: 16)
        moneyEarned.lineBreakMode = .byWordWrapping
        moneyEarned.numberOfLines = 0
        view.addSubview(moneyEarned)
        
        jobsCreatedAmt = UILabel()
        jobsCreatedAmt.text = "13"
        jobsCreatedAmt.textColor = .white
        jobsCreatedAmt.textAlignment = .center
        jobsCreatedAmt.font = UIFont(name: "Montserrat-Bold", size: 28)
        view.addSubview(jobsCreatedAmt)
        

        moneyEarnedAmt = UILabel()
        moneyEarnedAmt.text = "$15.00"
        moneyEarnedAmt.textColor = .white
        moneyEarnedAmt.textAlignment = .center
        moneyEarnedAmt.font = UIFont(name: "Montserrat-Bold", size: 28)
        view.addSubview(moneyEarnedAmt)
        
        jobsDoneAmt = UILabel()
        jobsDoneAmt.text = "2"
        jobsDoneAmt.textColor = .white
        jobsDoneAmt.textAlignment = .center
        jobsDoneAmt.font = UIFont(name: "Montserrat-Bold", size: 28)
        view.addSubview(jobsDoneAmt)
        
        personalLabel = UILabel()
        personalLabel.text = "Personal:"
        personalLabel.textColor = .white
        personalLabel.font = UIFont(name: "Montserrat", size: 20)
        personalLabel.font = UIFont.systemFont(ofSize: 16)
        view.addSubview(personalLabel)
        
        
        textField1 = UITextField()
        textField1.placeholder = "jc2547@cornell.edu"
        textField1.borderStyle = .roundedRect
        view.addSubview(textField1)


        textField2 = UITextField()
        textField2.placeholder = "(219)-352-4521"
        textField2.borderStyle = .roundedRect
        view.addSubview(textField2)

        textField3 = UITextField()
        textField3.placeholder = "@JavierC02"
        textField3.borderStyle = .roundedRect
        view.addSubview(textField3)
        
        editButton = UIButton()
        editButton.setTitle("Edit Profile", for: .normal)
        editButton.titleLabel?.font = UIFont(name: "Montserrat-Bold", size: 16)
        editButton.layer.shadowRadius = 2
        editButton.layer.shadowOpacity = 0.3
        editButton.layer.shadowColor = UIColor.black.cgColor
//        editButton.backgroundColor = .white
//        editButton.layer.masksToBounds = true
//        editButton.layer.cornerRadius = buttonHeight/2
        view.addSubview(editButton)
        
        setUpConstraints()
    }
    
    func setUpConstraints() {
        
        dollar.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(10)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-70)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-10)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
        }
        
        profileButton.snp.makeConstraints { (make) in
            make.top.equalTo(view.safeAreaLayoutGuide.snp.top).offset(14)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(view.safeAreaLayoutGuide.snp.top).offset(70)
            make.width.equalTo(60)
        }
        
        profilePicture.snp.makeConstraints { (make) in
            make.top.equalTo(profileButton.snp.bottom).offset(16)
            make.centerX.equalTo(view.snp.centerX)
            make.height.equalTo(height)
            make.width.equalTo(height)
        }
        
        userName.snp.makeConstraints { (make) in
            make.top.equalTo(profilePicture.snp.bottom).offset(10)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(profilePicture.snp.bottom).offset(45)
        }
        
        ratingLabel.snp.makeConstraints { (make) in
            make.top.equalTo(userName.snp.bottom).offset(4)
            make.centerX.equalTo(view.snp.centerX)
            make.bottom.equalTo(userName.snp.bottom).offset(20)
        }
        
        jobsCreated.snp.makeConstraints { (make) in
            make.top.equalTo(ratingLabel.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(30)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(100)
            make.bottom.equalTo(ratingLabel.snp.bottom).offset(50)
        }
        
        jobsDone.snp.makeConstraints { (make) in
            make.top.equalTo(ratingLabel.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-100)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
            make.bottom.equalTo(ratingLabel.snp.bottom).offset(50)
        }
        
        moneyEarned.snp.makeConstraints { (make) in
            make.top.equalTo(ratingLabel.snp.bottom)
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX)
            make.width.equalTo(jobsDone.snp.width)
            make.bottom.equalTo(ratingLabel.snp.bottom).offset(50)
        }
        
        jobsCreatedAmt.snp.makeConstraints { (make) in
            make.top.equalTo(jobsCreated.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(30)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(100)
            make.bottom.equalTo(jobsCreatedAmt.snp.bottom).offset(50)
        }
        
        jobsDoneAmt.snp.makeConstraints { (make) in
            make.top.equalTo(jobsDone.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-100)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-30)
            make.bottom.equalTo(jobsDoneAmt.snp.bottom).offset(50)
        }

        moneyEarnedAmt.snp.makeConstraints { (make) in
            make.top.equalTo(moneyEarned.snp.bottom)
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX)
            make.width.equalTo(120)
            make.bottom.equalTo(moneyEarnedAmt.snp.bottom).offset(50)
        }
        
        personalLabel.snp.makeConstraints { (make) in
            make.top.equalTo(jobsCreatedAmt.snp.bottom).offset(30)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(30)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(100)
            make.bottom.equalTo(jobsCreatedAmt.snp.bottom).offset(42)
        }
        
        textField1.snp.makeConstraints { (make) in
            make.top.equalTo(personalLabel.snp.bottom).offset(4)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(15)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-15)
            make.bottom.equalTo(textField1.snp.top).offset(35)
        }
        
        textField2.snp.makeConstraints { (make) in
            make.top.equalTo(textField1.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(15)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-15)
            make.bottom.equalTo(textField2.snp.top).offset(35)
        }
        
        textField3.snp.makeConstraints { (make) in
            make.top.equalTo(textField2.snp.bottom)
            make.leading.equalTo(view.safeAreaLayoutGuide.snp.leading).offset(15)
            make.trailing.equalTo(view.safeAreaLayoutGuide.snp.trailing).offset(-15)
            make.bottom.equalTo(textField3.snp.top).offset(35)
        }
        
        editButton.snp.makeConstraints { (make) in
            make.top.equalTo(textField3.snp.bottom).offset(30)
            make.centerX.equalTo(view.safeAreaLayoutGuide.snp.centerX)
            make.width.equalTo(buttonHeight)
            make.height.equalTo(15)
        }
        
    }
    
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    @objc func dollarButtonTapped() {
        let transition = CATransition()
        transition.duration = 0.4
        transition.type = CATransitionType.push
        transition.subtype = CATransitionSubtype.fromRight
        transition.timingFunction = CAMediaTimingFunction(name:CAMediaTimingFunctionName.easeInEaseOut)
        view.window!.layer.add(transition, forKey: kCATransition)
        dismiss(animated: false, completion: nil)
        
    }

}
