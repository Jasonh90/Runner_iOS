//
//  JobDetailsClass.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/26/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import Foundation

struct user: Codable {
    var user_id: Int
    var name: String
    
}

struct jobDetailsClass: Codable {

    var job_id: Int
    var title: String
    var category: String
    var description: String
    var date : String
    var start_time: String
    var end_time: String
    var first_Add: String
    var last_Add: String
    var cost: Int
    var profit: Int
    var amountpaidtoworker: Int
    var bosses: [user]
    var workers: [user]
}

struct jobResponse: Codable {
    var Success: Bool
    var Data: [jobDetailsClass]
}
