//
//  JobNetworkManager.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 5/3/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import Foundation
import Alamofire

class JobNetworkManager {
    
    private static let jobListEndpoint = "http://35.227.99.222/api/jobs/"
    private static let jobPostEndpoint = "http://35.227.99.222/api/job/1/"
    
    static func getJobs(completion: @escaping ([jobDetailsClass]) -> Void) {
        Alamofire.request(jobListEndpoint, method: .get).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
//                print ("Succeeded")
//                if let json = try? JSONSerialization.jsonObject(with: data, options: []) {
//                    print (json)
//                    let result = json
//                }
                let jsonDecoder = JSONDecoder()
                if let jobResults = try? jsonDecoder.decode(jobResponse.self, from: data) {
                    let jobs = jobResults.Data
                    print ("success")
                    completion(jobs)
                }
                else {
                    print ("failure")
                }
                
            case .failure(let error):
                print (error.localizedDescription)
                
            }
        }
    
    }
    
    static func postJob(posting: [String: Any]) {


        Alamofire.request(jobPostEndpoint, method: .post, parameters: posting, encoding:  JSONEncoding.default, headers: [:]).validate().responseData { (response) in
            switch response.result {
            case .success(let data):
                if let json = try? JSONSerialization.jsonObject(with: data, options: []) {
                    print ("Job Posted")
                }
                else {
                    print ("failure")
                }
            case .failure(let error):
                print ("failureeee")
                print (error.localizedDescription)
            }
        }
        
    }
    
}
