//
//  CreateJobFieldsClass.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/29/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import Foundation

struct CreateJobFieldsClass: Codable {
    var fieldName: String
//    
//    init(fieldName: String) {
//        self.fieldName = fieldName
//    }
}
