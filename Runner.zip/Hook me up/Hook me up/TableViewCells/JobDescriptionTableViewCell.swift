//
//  JobDescriptionTableViewCell.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/29/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit

class JobDescriptionTableViewCell: UITableViewCell {
    
    var textField: UITextField!
//    var button: UIButton!
    var button: UILabel!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        textField = UITextField()
        textField.backgroundColor = .white
        contentView.addSubview(textField)
        
        button = UILabel()
        button.backgroundColor = UIColorFromHex(rgbValue: 0x65C742, alpha: 1)
        button.text = "Create Job"
        button.font = UIFont(name: "Montserrat-Bold", size: 20)
        button.textColor = .white
        button.textAlignment = .center
        button.layer.cornerRadius = 5
        button.layer.masksToBounds = true
        contentView.addSubview(button)
    
        
        setUpConstraints()
    }
    
    func setUpConstraints() {
        button.snp.makeConstraints { (make) in
            make.top.equalTo(contentView.snp.top).offset(12)
            make.height.equalTo(40)
            make.leading.equalTo(contentView.safeAreaLayoutGuide.snp.leading).offset(40)
            make.trailing.equalTo(contentView.safeAreaLayoutGuide.snp.trailing).offset(-40)
        }
        
    }
    
    func configure(for job: CreateJobFieldsClass) {
        let attributes = [
            NSAttributedString.Key.foregroundColor: UIColor.lightGray,
            NSAttributedString.Key.font : UIFont(name: "Montserrat-Regular", size: 14)!
        ]
        textField.attributedPlaceholder = NSAttributedString(string: job.fieldName, attributes:attributes)
    }
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
