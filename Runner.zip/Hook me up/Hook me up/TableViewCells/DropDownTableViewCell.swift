//
//  DropDownTableViewCell.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/30/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import iOSDropDown

class DropDownTableViewCell: UITableViewCell {
    
    var dropdown: DropDown!
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        dropdown = DropDown()
        dropdown.backgroundColor = .white
        contentView.addSubview(dropdown)
        dropdown.arrowSize = 1
        dropdown.optionArray = ["Food", "Sports"]
        
        setUpConstraints()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpConstraints() {
        dropdown.snp.makeConstraints { (make) in
            make.top.equalTo(contentView.safeAreaLayoutGuide.snp.top).offset(1)
            make.height.equalTo(33)
            make.leading.equalTo(contentView.safeAreaLayoutGuide.snp.leading).offset(14)
            make.trailing.equalTo(contentView.safeAreaLayoutGuide.snp.trailing).offset(-5)
        }
        
    }
    
    func configure(for job: CreateJobFieldsClass) {
        let attributes = [
            NSAttributedString.Key.foregroundColor: UIColor.lightGray,
            NSAttributedString.Key.font : UIFont(name: "Montserrat-Regular", size: 14)!
        ]
        dropdown.attributedPlaceholder = NSAttributedString(string: job.fieldName, attributes:attributes)
    }

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
