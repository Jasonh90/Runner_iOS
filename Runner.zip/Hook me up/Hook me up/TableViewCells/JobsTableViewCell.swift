//
//  TableViewCell.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 4/26/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit
import SnapKit

class JobsTableViewCell: UITableViewCell {
    var jobTitle: UILabel!
    var time: UILabel!
    var date: UILabel!
    var amount: UILabel!
    var button: UIButton!
    var details: UILabel!
    var entryImage: UIImageView!
    
    let buttonHeight: CGFloat = 55
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        jobTitle = UILabel()
        jobTitle.font = UIFont(name: "Montserrat-Bold", size: 24)
        jobTitle.textColor = .black
        contentView.addSubview(jobTitle)
        
        time = UILabel()
        time.font = UIFont(name: "Montserrat-Regular", size: 14)
        time.textColor = .black
        contentView.addSubview(time)
        
        date = UILabel()
        date.font = UIFont(name: "Montserrat-Regular", size: 14)
        date.textColor = .black
        contentView.addSubview(date)
        
        amount = UILabel()
        amount.font = UIFont(name: "Montserrat-Bold", size: 24)
        amount.textColor = .black
        contentView.addSubview(amount)
        
//        button = UILabel()
//        button.layer.cornerRadius = buttonHeight/2
//        button.text = "$"
//        button.textColor = UIColorFromHex(rgbValue: 0x96Df7D , alpha: 1.0)
//        button.textAlignment = .center
//        button.font = UIFont(name: "Montserrat-Bold", size: 24)
//        button.backgroundColor = .white
//        button.layer.shadowColor = UIColor.black.cgColor
//        button.layer.shadowRadius = 3
//        button.layer.shadowOpacity = 0.3
        
        button = UIButton()
        button.layer.cornerRadius = buttonHeight/2
        button.setTitle("$", for: .normal)
        button.setTitleColor(UIColorFromHex(rgbValue: 0x96Df7D , alpha: 1.0), for: .normal)
        button.titleLabel?.textAlignment = .center
        button.titleLabel?.font = UIFont(name: "Montserrat-Bold", size: 24)
        button.backgroundColor = .white
        button.layer.shadowColor = UIColor.black.cgColor
        button.layer.shadowRadius = 3
        button.layer.shadowOpacity = 0.3
        button.layer.shadowOffset = CGSize(width: 1, height: 4)
        contentView.addSubview(button)
        
        
        details = UILabel()
        details.font = UIFont(name: "Montserrat-Regular", size: 12)
        details.text = "Details"
        details.textColor = UIColorFromHex(rgbValue: 0xBDB6B6, alpha: 1.0)
        contentView.addSubview(details)
        
        entryImage = UIImageView()
        entryImage.image = UIImage(named: "Circles")
        contentView.addSubview(entryImage)
        
        setUpConstraints()
    }
    
    func setUpConstraints() {
        jobTitle.snp.makeConstraints { (make) in
            make.top.equalTo(contentView.snp.top).offset(5)
            make.bottom.equalTo(jobTitle.snp.top).offset(25)
            make.leading.equalTo(contentView.snp.leading).offset(35)
            make.trailing.equalTo(jobTitle.snp.leading).offset(200)
        }
        
        time.snp.makeConstraints { (make) in
            make.top.equalTo(jobTitle.snp.bottom).offset(5)
            make.bottom.equalTo(time.snp.top).offset(15)
            make.leading.equalTo(contentView.snp.leading).offset(35)
            make.trailing.equalTo(jobTitle.snp.leading).offset(70)
        }
        
        date.snp.makeConstraints { (make) in
            make.top.equalTo(jobTitle.snp.bottom).offset(5)
            make.bottom.equalTo(date.snp.top).offset(15)
            make.leading.equalTo(time.snp.trailing).offset(5)
            make.trailing.equalTo(date.snp.leading).offset(70)
        }
        
        amount.snp.makeConstraints { (make) in
            make.top.equalTo(time.snp.bottom).offset(5)
            make.bottom.equalTo(amount.snp.top).offset(25)
            make.leading.equalTo(contentView.snp.leading).offset(35)
            make.trailing.equalTo(jobTitle.snp.leading).offset(200)
        }
        
        button.snp.makeConstraints { (make) in
            make.centerY.equalTo(contentView.snp.centerY)
            make.leading.equalTo(contentView.safeAreaLayoutGuide.snp.trailing).offset(-75)
            make.height.equalTo(buttonHeight)
            make.width.equalTo(buttonHeight)
        }
        
        entryImage.snp.makeConstraints { (make) in
            make.top.equalTo(contentView.snp.top).offset(8)
            make.bottom.equalTo(entryImage.snp.top).offset(30)
            make.leading.equalTo(contentView.snp.leading).offset(5)
            make.trailing.equalTo(contentView.snp.leading).offset(35)
        }
    }
    
    func configure(for job: jobDetailsClass) {
        jobTitle.text = job.title
        time.text = "@\(job.start_time)"
        amount.text = "$\(String(job.profit))"
        date.text = job.date
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func UIColorFromHex(rgbValue:UInt32, alpha:Double=1.0)->UIColor {
        let red = CGFloat((rgbValue & 0xFF0000) >> 16)/256.0
        let green = CGFloat((rgbValue & 0xFF00) >> 8)/256.0
        let blue = CGFloat(rgbValue & 0xFF)/256.0
        
        return UIColor(red:red, green:green, blue:blue, alpha:CGFloat(alpha))
    }
    

}
