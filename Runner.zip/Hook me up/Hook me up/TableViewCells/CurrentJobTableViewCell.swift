//
//  CurrentJobTableViewCell.swift
//  Hook me up
//
//  Created by Abhimanyu Kompella on 5/5/19.
//  Copyright © 2019 Abhimanyu Kompella. All rights reserved.
//

import UIKit

class CurrentJobTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
